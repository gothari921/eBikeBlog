---
layout: default
title: Specifications
---

# E-Bike Specifications

Here are the specifications for the E-Bike project:

- Motor: 500W
- Battery: 48V 15Ah
- Range: ~40 miles
- Frame: Aluminum
- Top Speed: 28 mph
