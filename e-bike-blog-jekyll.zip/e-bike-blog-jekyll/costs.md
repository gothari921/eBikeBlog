---
layout: default
title: Costs
---

# E-Bike Costs

| Component       | Cost   |
|-----------------|--------|
| Motor           | $300   |
| Battery         | $400   |
| Controller      | $100   |
| Frame           | $250   |
| Miscellaneous   | $150   |
| **Total**       | **$1,200** |
