---
layout: default
title: "First Blog Post"
date: 2025-09-12
---

Welcome to the first post on the E-Bike Blog! This is where the journey begins. I'll be documenting specifications, costs, and thoughts as I build my e-bike project.
