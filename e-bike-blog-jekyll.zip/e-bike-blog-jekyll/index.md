---
layout: default
title: Home
---

# Welcome to the E-Bike Blog

This is the landing page of the E-Bike Blog. Use the navigation to explore specifications, costs, and blog posts.
